package com.client;

public class CounterBean {
	private int counterValue;
	
	CounterBean() {
		
	}
	
	CounterBean(int v) {
		this.counterValue = v;
	}

	public int getCounterValue() {
		return counterValue;
	}

	public void setCounterValue(int counterValue) {
		this.counterValue = counterValue;
	}
	
	
}
