package com.client;

import java.io.IOException;

import javax.ejb.EJB;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.counter.CounterEjbRemote;

@WebServlet("/CounterServlet")
public class CounterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	@EJB
	private CounterEjbRemote ejb;
	
    public CounterServlet() {
        super();
    }

	@Override
	public void init() throws ServletException {
		try {
			ejb = (CounterEjbRemote) new InitialContext().
					lookup("java:global/CounterEJB/CounterEjb!com.counter.CounterEjbRemote");
			System.out.println("ejb lookuped successfully");
		} 
		catch (NamingException e) {
			e.printStackTrace();
		}
	}    

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		String paramReset = request.getParameter("reset");
		if (paramReset!=null && paramReset.equals("1")) {
			ejb.resetCounter();
		}
		
		ejb.hitCounter();
		CounterBean cb = new CounterBean( ejb.getCounter() );
		request.setAttribute("counterBean", cb);
		request.getRequestDispatcher("/WEB-INF/counter.jsp")
			.forward(request, response);
	}

}
