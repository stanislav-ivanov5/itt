package com.counter;

import javax.ejb.LocalBean;
import javax.ejb.Stateful;

/**
 * Session Bean implementation class CounterEjb
 */
@Stateful
@LocalBean
public class CounterEjb implements CounterEjbRemote, CounterEjbLocal {

	private int counter;

	@Override
	public void hitCounter() {
		counter++;
	}

	@Override
	public int getCounter() {
		return counter;
	}

	@Override
	public void resetCounter() {
		counter = 0;
	}

}
