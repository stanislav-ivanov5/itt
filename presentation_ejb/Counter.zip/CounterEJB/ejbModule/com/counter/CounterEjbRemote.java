package com.counter;

import javax.ejb.Remote;

@Remote
public interface CounterEjbRemote {

	public void hitCounter();
	public int getCounter();
	public void resetCounter();
	
}
