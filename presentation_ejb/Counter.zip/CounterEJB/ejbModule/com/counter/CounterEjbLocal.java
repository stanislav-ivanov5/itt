package com.counter;

import javax.ejb.Local;

@Local
public interface CounterEjbLocal {

	public void hitCounter();
	public int getCounter();
	public void resetCounter();
}
