package com.calc;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class CalculatorEJB
 */
@Stateless
@LocalBean
public class CalculatorEJB implements CalculatorEjbLocal {

	@Override
	public double add(double x, double y) {
		return x + y;
	}

	@Override
	public double sub(double x, double y) {
		return x - y;
	}

	@Override
	public double div(double x, double y) {
		return x / y;
	}

	@Override
	public double mul(double a, double b) {
		return a * b;
	}

    

}
