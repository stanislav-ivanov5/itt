package com.calcclient;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.calc.CalculatorEJB;

/**
 * Servlet implementation class CalculateServlet
 */
@WebServlet("/CalculateClientServlet")
public class CalculateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	@EJB
	private CalculatorEJB ejb;

    public CalculateServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	doPost(request, response);
    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String operation = request.getParameter("operation");
    	double a = Double.parseDouble(request.getParameter("a"));
    	double b = Double.parseDouble(request.getParameter("b"));
    	
    	double result = 0;
    	if ("add".equals(operation)) {
			result = this.ejb.add(a, b);
		}
		if ("sub".equals(operation)) {
			result = this.ejb.sub(a, b);
		}
		if ("div".equals(operation)) {
			result = this.ejb.div(a, b);
		}
		if ("mul".equals(operation)) {
			result = this.ejb.mul(a, b);
		}		
    	
		CalculatorBean cb = new CalculatorBean();
		cb.setA(a);
		cb.setB(b);
		cb.setOperation(operation);
		cb.setResult(result);
		
		request.setAttribute("calcBean", cb);
		request.getRequestDispatcher("/index.jsp").forward(request, response);
	}

}
